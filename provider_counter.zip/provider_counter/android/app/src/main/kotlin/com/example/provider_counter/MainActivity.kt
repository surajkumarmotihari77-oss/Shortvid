package com.example.provider_counter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
